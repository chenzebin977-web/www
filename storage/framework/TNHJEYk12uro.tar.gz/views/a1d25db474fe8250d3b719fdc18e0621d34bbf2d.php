<div class="<?php echo e($viewClass['form-group'], false); ?> <?php echo !$errors->has($column) ?: 'has-error'; ?>">
    <label class="<?php echo e($viewClass['label'], false); ?> control-label"><?php echo $label; ?></label>
    <div class="<?php echo e($viewClass['field'], false); ?> select-resource">
        <?php echo $__env->make('admin::form.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="input-group">
            <div <?php echo $attributes; ?>>
                <span class="default-text" style="opacity:0.75"><?php echo e($placeholder, false); ?></span>
                <span class="option d-none"></span>
            </div>

            <?php if(! $disabled): ?>
                <input name="<?php echo e($name, false); ?>" type="hidden" id="hidden-<?php echo e($id, false); ?>" value="<?php echo e(implode(',', \Dcat\Admin\Support\Helper::array($value)), false); ?>" />
            <?php endif; ?>
            <div class="input-group-append">
                <?php echo $dialog; ?>

            </div>
        </div>

        <?php echo $__env->make('admin::form.help-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
</div><?php /**PATH /www/wwwroot/43.242.128.5_1191/project04-admin/vendor/dcat/laravel-admin/src/../resources/views/form/selecttable.blade.php ENDPATH**/ ?>