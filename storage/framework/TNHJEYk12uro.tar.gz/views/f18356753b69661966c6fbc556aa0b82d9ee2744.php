<ul class="nav navbar-nav" style="padding: 0 10px;">
    <li class="dropdown dropdown-language nav-item">
        <a class="dropdown-toggle nav-link" href="#" id="dropdown-flag" data-toggle="dropdown">
           
            <i class="fa fa-language"></i>
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdown-flag">
            <?php $__currentLoopData = $language_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="dropdown-item" data-language="en" onclick="changeLang('<?php echo e($key, false); ?>')">
                    <a><?php echo e(admin_trans_field($value['name']), false); ?></a>
                    
                </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
</ul>

<style>
    .dropdown-item a{
        padding: 15px;
    }
</style>

<script>
    function changeLang(lang){
        $.ajax({
            url: '/<?php echo e(config('admin.route.prefix'), false); ?>/language?language='+lang,
            method:'get',
            success: function(data){
                window.location.reload()
            },
        })
    }
</script>
<?php /**PATH /www/wwwroot/43.242.128.5_1191/project04-admin/resources/views/admin/language.blade.php ENDPATH**/ ?>