<div>
    <div id="team-size-table-1"><?php echo $table1; ?></div>
    <div id="team-size-table-2"><?php echo $table2; ?></div>
    <div id="team-size-grid-table"><?php echo $grid; ?></div>
</div>

<style>
    .top-table .box-footer{
        display: none;
    }
</style>

<script>
    console.log('<?php echo e($tabId, false); ?>')
    //点击按钮
    $("#<?php echo e($tabId, false); ?>").find(".team_detail").on("click",function (){
        let url = $(this).attr('data-url')
        $.ajax({
            url: url,
            type: 'GET',
            beforeSend: function() {
                Dcat.loading();
            },
            complete: function() {
                Dcat.loading(false);
            },
            success: function(response) {
                $("#<?php echo e($tabId, false); ?>").find('.async-table').html(response)
                init()
            },
            error: function(xhr) {
                Dcat.handleAjaxError(xhr);
            }
        })
    })
    //筛选打开关闭事件
    function changeFilter(){
        $("#<?php echo e($tabId, false); ?>").find(".btn-group.filter-button-group.dropdown").on("click",function (){
            let className = $(this).parents('.custom-data-table-header').siblings('.filter-box.card.p-2').attr('class')
            if(className.includes('d-none')){
                $(this).parents('.dcat-box.custom-data-table.dt-bootstrap4').find('.filter-box.card.p-2').removeClass('d-none')
            }else{
                $(this).parents('.dcat-box.custom-data-table.dt-bootstrap4').find('.filter-box.card.p-2').addClass('d-none')
            }
        })
    }
    //重写刷新按钮
    refresh()
    function refresh(){
        $("#<?php echo e($tabId, false); ?>").find(".btn.btn-primary.grid-refresh.btn-mini.btn-outline").on("click",function (){
            let url = $(this).parents('.async-table').attr('data-url')
            $.ajax({
                url: url,
                type: 'GET',
                beforeSend: function() {
                    Dcat.loading();
                },
                complete: function() {
                    Dcat.loading(false);
                },
                success: function(response) {
                    $("#<?php echo e($tabId, false); ?>").find('.async-table').html(response)
                    init()
                },
                error: function(xhr) {
                    Dcat.handleAjaxError(xhr);
                }
            })
        })
    }
    //重写搜索
    function search(){
        $("#<?php echo e($tabId, false); ?>").find(".btn.btn-primary.btn-sm.btn-mini.submit").on("click",function (){
            let url = $("#<?php echo e($tabId, false); ?>").find('form.form-horizontal').attr('action')
            let formData = $("#<?php echo e($tabId, false); ?>").find('form.form-horizontal').serializeArray();
            $.ajax({
                url: url,
                type: 'GET',
                data: formData,
                beforeSend: function() {
                    Dcat.loading();
                },
                complete: function() {
                    Dcat.loading(false);
                },
                success: function(response) {
                    $("#<?php echo e($tabId, false); ?>").find('.async-table').html(response)
                    init()
                },
                error: function(xhr) {
                    Dcat.handleAjaxError(xhr);
                }
            })
        })
    }

    //重写重置
    function reset(){
        $("#<?php echo e($tabId, false); ?>").find(".reset.btn.btn-white.btn-sm").on("click",function (e){
            e.preventDefault()
            let url = $(this).attr('href')
            $.ajax({
                url: url,
                type: 'GET',
                beforeSend: function() {
                    Dcat.loading();
                },
                complete: function() {
                    Dcat.loading(false);
                },
                success: function(response) {
                    $("#<?php echo e($tabId, false); ?>").find('.async-table').html(response)
                    init()
                },
                error: function(xhr) {
                    Dcat.handleAjaxError(xhr);
                }
            })
        })
    }

    //重写翻页
    function page(){
        $("#<?php echo e($tabId, false); ?>").find(".page-link").on("click",function (e){
            e.preventDefault()
            let url = $(this).attr('href')
            $.ajax({
                url: url,
                type: 'GET',
                beforeSend: function() {
                    Dcat.loading();
                },
                complete: function() {
                    Dcat.loading(false);
                },
                success: function(response) {
                    $("#<?php echo e($tabId, false); ?>").find('.async-table').html(response)
                    init()
                },
                error: function(xhr) {
                    Dcat.handleAjaxError(xhr);
                }
            })
        })
    }

    //初始化
    function init(){
        changeFilter()
        $("#<?php echo e($tabId, false); ?>").find('select').select2();
        refresh()
        // 禁用默认提交
        $("#<?php echo e($tabId, false); ?>").find('form.form-horizontal').on('submit', function () {
            return false;
        })
        search()
        reset()
        page()
    }
</script>
<?php /**PATH /www/wwwroot/43.242.128.5_1191/project04-admin/resources/views/admin/member/team.blade.php ENDPATH**/ ?>